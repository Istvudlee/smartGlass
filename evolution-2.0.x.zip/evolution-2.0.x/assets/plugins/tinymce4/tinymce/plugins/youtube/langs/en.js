tinymce.addI18n('en',{
	'Choose YouTube Video'  : 'Search YouTube Video',
	'Insert Youtube video'  : 'Insert Youtube video',
	'width'					: 'Width',
	'height'				: 'Height',
	'skin'					: 'Skin',
	'dark'          		: 'dark',
	'light'         		: 'light',
	'Search'        		: 'Search',
	'Youtube URL'   		: 'Youtube URL',
	'Title'         		: 'Title',
	'Insert and Close'		: 'Insert and Close',
	'Insert'				: 'Insert',
	'Load More'				: 'Load More',
	'cancel'				: 'cancel'
});
