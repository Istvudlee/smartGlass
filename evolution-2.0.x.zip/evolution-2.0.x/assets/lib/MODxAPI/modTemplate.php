<?php
include_once(dirname(__FILE__) . "/autoTable.abstract.php");

/**
 * Class modTemplate
 */
class modTemplate extends autoTable
{
    /**
     * @var string
     */
    protected $table = "site_templates";
}
