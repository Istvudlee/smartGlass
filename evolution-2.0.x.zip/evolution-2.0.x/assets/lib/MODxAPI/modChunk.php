<?php
include_once(dirname(__FILE__) . "/autoTable.abstract.php");

/**
 * Class modChunk
 */
class modChunk extends autoTable
{
    /**
     * @var string
     */
    protected $table = "site_htmlsnippets";
}
