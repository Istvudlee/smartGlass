<?php
include_once(dirname(__FILE__) . "/autoTable.abstract.php");

/**
 * Class modPlugin
 */
class modPlugin extends autoTable
{
    /**
     * @var string
     */
    protected $table = "site_plugins";
}
