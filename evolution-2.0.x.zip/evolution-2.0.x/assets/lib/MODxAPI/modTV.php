<?php
include_once(dirname(__FILE__) . "/autoTable.abstract.php");

/**
 * Class modTV
 */
class modTV extends autoTable
{
    /**
     * @var string
     */
    protected $table = "site_tmplvars";
}
