<?php
include_once(dirname(__FILE__) . "/autoTable.abstract.php");

/**
 * Class modCategories
 */
class modCategories extends autoTable
{
    /**
     * @var string
     */
    protected $table = "categories";
}
