<?php
if ( ! defined('MODX_BASE_PATH')) {
    die('What are you doing? Get out of here!');
}

setlocale(LC_ALL, 'pl_PL.UTF-8');

$_lang = array(
    /** nazwy miesięcy */
    '1'  => 'Styczeń',
    '2'  => 'Luty',
    '3'  => 'Marzec',
    '4'  => 'Kwiecień',
    '5'  => 'Maj',
    '6'  => 'Czerwiec',
    '7'  => 'Lipiec',
    '8'  => 'Sierpień',
    '9'  => 'Wrzesień',
    '10' => 'Październik',
    '11' => 'Listopad',
    '12' => 'Grudzień'
);
return $_lang;
