<?php
if ( ! defined('MODX_BASE_PATH')) {
    die('What are you doing? Get out of here!');
}

setlocale(LC_ALL, 'ja_JP.UTF-8');

$_lang = array();
$_lang['next'] = '次へ';
$_lang['prev'] = '戻る';

return $_lang;
